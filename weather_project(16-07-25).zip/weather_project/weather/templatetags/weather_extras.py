# weather_extras.py

from django import template
from datetime import datetime

register = template.Library()

@register.filter
def date(value, format='%B %d'):
    if isinstance(value, str):
        value = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
    return value.strftime(format)
