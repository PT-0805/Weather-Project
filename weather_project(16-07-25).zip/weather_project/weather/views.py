from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
# from django.forms import UserForm
from .forms import UserForm
from .services import get_weather_data
from datetime import datetime  # Add this line to import datetime module

@login_required
def edit_profile(request):
    if request.method == 'POST':
        user_form = UserForm(request.POST, instance=request.user)
        if user_form.is_valid():
            user_form.save()
            return redirect('home')
    else:
        user_form = UserForm(instance=request.user)
    return render(request, 'edit_profile.html', {'user_form': user_form})

def home(request):
    city = request.GET.get('city', 'Ahmedabad')
    weather_data = get_weather_data(city)
    # return render(request, 'weather/home.html', {'weather_data': weather_data})
    # return render(request, 'weather/home.html', {'weather_data': weather_data, 'city': city})

    if weather_data and 'list' in weather_data:
        next_five_days = weather_data['list']  # This contains the 5-day forecast in 3-hour intervals
    else:
        next_five_days = None

    # Format date and time in next_five_days
    if next_five_days:
        for forecast in next_five_days:
            forecast_datetime = datetime.strptime(forecast['dt_txt'], '%Y-%m-%d %H:%M:%S')
            forecast['formatted_date'] = forecast_datetime.strftime('%B %d, %Y')
            forecast['formatted_time'] = forecast_datetime.strftime('%H:%M %p')

    return render(request, 'weather/home.html', {'city': city, 'weather_data': weather_data, 'next_five_days': next_five_days})

def about(request):
    return render(request, 'weather/about.html')

def login_view(request):
    form = AuthenticationForm()
    return render(request, 'account/login.html', {'form': form})

def signup_view(request):
    form = UserCreationForm()
    return render(request, 'account/signup.html', {'form': form})

def test_base(request):
    return render(request, 'base.html')