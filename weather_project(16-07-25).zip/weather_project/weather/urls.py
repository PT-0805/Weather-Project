# weather/urls.py
"""
URL configuration for weather_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# from django.contrib import admin
from django.urls import path, include
from . import views
from django.contrib.auth import views as auth_views
# from allauth.account import views as allauth_views
# from django.contrib.auth import views as auth_views
# from weather import views
# from allauth.account.views import PasswordResetView, PasswordResetDoneView, PasswordResetConfirmView, PasswordResetCompleteView
# from allauth.account import views as allauth_views

urlpatterns = [    
    path('', views.home, name='home'),    
    path('about/', views.about, name='about'),
    path('test_base/', views.test_base, name='test_base'),
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),

    # Password reset paths using Django built-in views
    path('password/reset/', auth_views.PasswordResetView.as_view(template_name='account/password_reset_form.html'), name='password_reset'),
    path('password/reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='account/password_reset_done.html'), name='password_reset_done'),
    path('password/reset/confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='account/password_reset_confirm.html'), name='password_reset_confirm'),
    path('password/reset/complete/', auth_views.PasswordResetCompleteView.as_view(template_name='account/password_reset_complete.html'), name='password_reset_complete'),

    # Logout path using Django Allauth
    path('account/', include('allauth.urls')),  # Add this line to include allauth URLs

    # path('password/reset/', allauth_views.PasswordResetView.as_view(template_name='account/password_reset_form.html'), name='account_reset_password'),
    # path('password/reset/done/', allauth_views.PasswordResetDoneView.as_view(template_name='account/password_reset_done.html'), name='account_reset_password_done'),
    # path('password/reset/confirm/<uidb64>/<token>/', allauth_views.PasswordResetConfirmView.as_view(template_name='account/password_reset_confirm.html'), name='account_reset_password_confirm'),
    # path('password/reset/complete/', allauth_views.PasswordResetCompleteView.as_view(template_name='account/password_reset_complete.html'), name='account_reset_password_complete'),


    # path('password/reset/', allauth_views.PasswordResetView.as_view(), name='account_reset_password'),
    # path('password/reset/done/', allauth_views.PasswordResetDoneView.as_view(), name='account_reset_password_done'),
    # path('password/reset/confirm/<uidb64>/<token>/', allauth_views.PasswordResetConfirmView.as_view(), name='account_reset_password_confirm'),
    # path('password/reset/complete/', allauth_views.PasswordResetCompleteView.as_view(), name='account_reset_password_complete'),

    # path('password/reset/', auth_views.PasswordResetView.as_view(template_name='account/password_reset_form.html'), name='account_reset_password'),
    # path('password/reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='account/password_reset_done.html'), name='account_reset_password_done'),
    # path('password/reset/confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='account/password_reset_confirm.html'), name='account_reset_password_confirm'),
    # path('password/reset/complete/', auth_views.PasswordResetCompleteView.as_view(template_name='account/password_reset_complete.html'), name='account_reset_password_complete'),

]
