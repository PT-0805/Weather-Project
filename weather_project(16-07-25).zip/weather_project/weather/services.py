import requests

def get_weather_data(city):
    api_key = '6fa453d5b4165a3a26cc355f98fb919b'  # Replace with your actual API key
    # url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric'
    geocode_url = f'http://api.openweathermap.org/geo/1.0/direct?q={city}&limit=1&appid={api_key}'
    geocode_response = requests.get(geocode_url)

    # Debugging: Print the geocode response
    print('Geocode Response:', geocode_response.json())
    
    if geocode_response.status_code != 200 or not geocode_response.json():
        print('Geocode API call failed')
        return None
    location = geocode_response.json()[0]
    lat, lon = location['lat'], location['lon']

    forecast_url = f'http://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={api_key}&units=metric'
    response = requests.get(forecast_url)
    
    # Debugging: Print the forecast response
    print('Forecast Response:', response.json())
    
    if response.status_code == 200:
        return response.json()
    else:
        print('Forecast API call failed')
        return None